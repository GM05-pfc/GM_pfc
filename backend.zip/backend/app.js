const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const client = require('prom-client');

const app = express();
const itemsRouter = require('./routes/items');

const corsOptions = {
  origin: "*",
  methods: ["GET", "POST"],
  allowedHeaders: ["Content-Type"]
};
app.use(cors(corsOptions));

const register = new client.Registry();
client.collectDefaultMetrics({ register });

const frontendTimeOnPage = new client.Histogram({
  name: 'frontend_time_on_page_seconds',
  help: 'Tiempo que los usuarios pasan en la página (en segundos)',
  buckets: [1, 3, 5, 10, 20, 30, 60, 120]
});
register.registerMetric(frontendTimeOnPage);

app.get('/metrics', async (req, res) => {
  res.set('Content-Type', register.contentType);
  res.end(await register.metrics());
});

app.post('/frontend-metrics', express.json(), (req, res) => {
  try {
    const { metric, value } = req.body;
    if (metric === 'time_on_page' && typeof value === 'number') {
      frontendTimeOnPage.observe(value / 1000);
      console.log(`Métrica recibida: ${value}ms`);
      res.status(200).send('Métrica registrada');
    } else {
      console.error('Métrica inválida:', req.body);
      res.status(400).send('Formato de métrica incorrecto');
    }
  } catch (err) {
    console.error('Error en frontend-metrics:', err);
    res.status(500).send('Error interno');
  }
});

app.use(express.json());

mongoose.connect('mongodb://gerard:1029384756@172.26.137.82:30451/projecte_bd', {
  useNewUrlParser: true,
  useUnifiedTopology: true
});

const db = mongoose.connection;
db.on('error', (error) => console.error(error));
db.once('open', () => console.log('Conectado a la base de datos'));

app.use('/items', itemsRouter);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Servidor iniciado en el puerto ${PORT}`));
