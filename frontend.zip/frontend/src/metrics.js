// src/metrics.js

export function reportTimeOnPage() {
    const start = Date.now();
  
    // Cuando el usuario se va de la página
    window.addEventListener("beforeunload", () => {
      const duration = Date.now() - start;
  
      fetch("http://host.minikube.internal:3000/frontend-metrics", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          metric: "time_on_page",
          value: duration
        })
      }).catch(err => {
        console.error("Error enviando métricas:", err);
      });
    });
  }
  