import React, { useState } from "react";
import axios from "axios";

function AddItem() {
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [price, setPrice] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    axios.post("https://localhost:3000/items", { name, description, price })
      .then(() => alert("Item agregat correctament"))
      .catch(error => console.error("Error al afegir item:", error));
  };

  return (
    <div>
      <h2>Agregar un nuevo item</h2>
      <form onSubmit={handleSubmit}>
        <label>Nom:</label>
        <input type="text" value={name} onChange={(e) => setName(e.target.value)} required />

        <label>Descripció:</label>
        <input type="text" value={description} onChange={(e) => setDescription(e.target.value)} />

        <label>Preu (€):</label>
        <input type="number" value={price} onChange={(e) => setPrice(e.target.value)} required />

        <button type="submit">Afegir</button>
      </form>
    </div>
  );
}

export default AddItem;
