import React, { useEffect, useState } from "react";
import axios from "axios";
function Home() {
  const [items, setItems] = useState([]);

  useEffect(() => {
    axios.get("https://localhost:3000/items")
      .then(response => setItems(response.data))
      .catch(error => console.error("Error al obtindre les dades:", error));
  }, []);

  return (
    <div>
      <h2>Llista de Items</h2>
      <ul>
        {items.map(item => (
          <li key={item._id}>
            {item.name} - {item.price}€
          </li>
        ))}
      </ul>
    </div>
  );
}
export default Home;
