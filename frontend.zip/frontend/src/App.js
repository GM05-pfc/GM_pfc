import React, { useEffect } from "react";
import { BrowserRouter as Router, Route, Routes, Link } from "react-router-dom";
import Home from "./pages/Home";
import AddItem from "./pages/AddItem";

function App() {
  useEffect(() => {
    const start = performance.now();

    const sendMetric = () => {
      const duration = performance.now() - start;
      console.log("Tiempo en pantalla (ms):", duration);

      fetch("https://192.168.1.62:3000/frontend-metrics", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          metric: "time_on_page",
          value: duration
        })
      })
      .then(() => {
        console.log("Métrica enviada correctamente al backend");
      })
      .catch((err) => {
        console.error("Error enviando métrica:", err);
      });
    };

    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "hidden") {
        sendMetric();
      }
    });

    return () => {
      document.removeEventListener("visibilitychange", sendMetric);
    };
  }, []);

  return (
    <Router>
      <div>
        <nav>
          <Link to="/">Inicio</Link> | <Link to="/add">Agregar Item</Link>
        </nav>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/add" element={<AddItem />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
