import React, { useState } from "react";
const ItemForm = ({ addItem }) => {
  const [input, setInput] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    if (input.trim() !== "") {
      addItem(input);
      setInput("");
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        type="text"
        value={input}
        onChange={(e) => setInput(e.target.value)}
        placeholder="Añadir nuevo item"
      />
      <button type="submit">Agregar</button>
    </form>
  );
};

export default ItemForm;
